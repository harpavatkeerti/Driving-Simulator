Group 8

Hardware Based Game

Members:
Aman Mishra 170101005
Keerti Harpavat 170101031
Priyanshu Singh 170101049
Utkarsh Mishra 170101083

Arduino code is there in ./group_08_arduino_code
./group_08_RPi_code/_group_08_hardware_game.py contains the entire code
The other files contain relevant codes for each actuator and sensor