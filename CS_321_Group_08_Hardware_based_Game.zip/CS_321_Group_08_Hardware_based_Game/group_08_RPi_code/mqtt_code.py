                                            # MQTT code for publishing
publisher = mqtt.Client()
publisher.connect("172.16.117.128",1883,60)
message = "Going reverse"
publisher.publish("driving simulator",message)
publisher.disconnect()
