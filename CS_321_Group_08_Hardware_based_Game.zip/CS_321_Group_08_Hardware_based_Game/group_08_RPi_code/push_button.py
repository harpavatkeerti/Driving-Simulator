                                                # Push button
GPIO.setup(27, GPIO.IN, pull_up_down=GPIO.PUD_UP)

button_state = GPIO.input(27)
if button_state == GPIO.HIGH:
    # Required code
